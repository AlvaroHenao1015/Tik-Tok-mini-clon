//
//  NotificationCell.swift
//  TikTokClone
//
//  Created by Alvaro Henao on 20/01/24.
//

import SwiftUI

struct NotificationCell: View {
    var body: some View {
        HStack{
            Image(systemName: "person.circle.fill")
                .resizable()
                .foregroundColor(Color(.systemGray5))
                .frame(width: 28, height: 28)
            
            HStack {
                Text("henaogonzalezalvaro ")
                    .font(.footnote)
                    .fontWeight(.semibold) +
                Text("liked one of your posts. ")
                    .font(.footnote) +
                Text("3d")
                    .font(.caption)
                    .foregroundColor(.gray )
            }
            
            Spacer()
            
            Rectangle()
                .frame(width: 48, height: 48)
                .clipShape(RoundedRectangle(cornerRadius: 6))
        }
        .padding(.horizontal)
    }
}

struct NotificationCell_Previews: PreviewProvider {
    static var previews: some View {
        NotificationCell()
    }
}
