//
//  ContentView.swift
//  TikTokClone
//
//  Created by Alvaro Henao on 19/01/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        MainTabView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
