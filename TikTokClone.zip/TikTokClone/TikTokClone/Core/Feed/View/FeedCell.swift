//
//  FeedCell.swift
//  TikTokClone
//
//  Created by Alvaro Henao on 19/01/24.
//

import SwiftUI
import AVKit

struct FeedCell: View {
    let post: Post
    var player: AVPlayer
    
    init(post: Post) {
        self.post = post
        self.player = AVPlayer(url: URL(string: post.videoUrl)!)
    }
    
    var body: some View {
        ZStack {
            CustomVideoPlayer(player: player)
                .frame(width: 393, height: 780)
            
            VStack {
                Spacer()
                
                HStack(alignment: .bottom){
                    VStack(alignment: .leading) {
                        Text("henaogonzalezalvaro")
                            .fontWeight(.semibold)
                        Text("Tell me every terrible thing you ever did, and let me love you anyway.")
                            
                    }
                    .foregroundColor(.white)
                    .font(.subheadline)
                    
                    Spacer()
                    
                    VStack(spacing: 28) {
                        Circle()
                            .frame(width: 48, height: 48)
                            .foregroundColor(.gray)
                        
                        Button{
                            
                        } label: {
                            VStack {
                                Image(systemName: "heart.fill")
                                    .resizable()
                                    .frame(width: 28, height: 28)
                                .foregroundColor(.white)
                                
                                Text("27")
                                    .font(.caption)
                                    .foregroundColor(.white)
                            }
                        }
                        
                        Button {
                            
                        } label: {
                            VStack {
                                Image(systemName: "ellipsis.bubble.fill")
                                    .resizable()
                                    .frame(width: 28, height: 28)
                                .foregroundColor(.white)
                                
                                Text("27")
                                    .font(.caption)
                                    .foregroundColor(.white)
                            }
                        }
                        
                        Button{
                            
                        } label: {
                            VStack {
                                Image(systemName: "bookmark.fill")
                                    .resizable()
                                    .frame(width: 22, height: 28)
                                    .foregroundColor(.white)
                                
                                Text("27")
                                    .font(.caption)
                                    .foregroundColor(.white)
                                
                            }
                        }
                        
                        Button {
                            
                        } label: {
                            VStack {
                                Image(systemName: "arrowshape.turn.up.right.fill")
                                    .resizable()
                                    .frame(width: 28, height: 28)
                                .foregroundColor(.white)
                            
                            Text("27")
                                .font(.caption)
                                .foregroundColor(.white)
                            }
                        }
                    }
                }
                .padding(.bottom, 5)
            }
            .padding()
        }
       /* .onAppear() {
            player.play()
        }*/
    }
}

struct FeedCell_Previews: PreviewProvider {
    static var previews: some View {
        FeedCell(post: Post(id: NSUUID().uuidString, videoUrl: ""))
    }
}
