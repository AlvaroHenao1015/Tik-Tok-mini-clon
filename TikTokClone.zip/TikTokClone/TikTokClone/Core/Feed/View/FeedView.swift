//
//  FeedView.swift
//  TikTokClone
//
//  Created by Alvaro Henao on 19/01/24.
//

import SwiftUI


struct FeedView: View {
    @StateObject var viewModel = FeedViewModel()
    var body: some View {
        ScrollView {
            LazyVStack(spacing: 0) {
                ForEach(viewModel.posts){ post in
                    FeedCell(post: post)
                }
            }
        }
        .ignoresSafeArea()
    }
}

struct FeedView_Previews: PreviewProvider {
    static var previews: some View {
        FeedView()
    }
}
