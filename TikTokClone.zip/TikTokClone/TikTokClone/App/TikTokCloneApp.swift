//
//  TikTokCloneApp.swift
//  TikTokClone
//
//  Created by Alvaro Henao on 19/01/24.
//

import SwiftUI

@main
struct TikTokCloneApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}
