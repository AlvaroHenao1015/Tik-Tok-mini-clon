//
//  Post.swift
//  TikTokClone
//
//  Created by Alvaro Henao on 22/01/24.
//

import Foundation

struct Post: Identifiable, Codable {
    let id: String
    let videoUrl: String
}
 
